<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDatasetsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('datasets', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->enum('gender',['Laki-laki','Perempuan']);
            $table->integer('tahun_masuk');
            $table->integer('tahun_lulus');
            $table->integer('lama_studi');
            $table->integer('ipk');
            $table->integer('waktu_tunggu');
            $table->integer('jumlah_matkul');
            $table->enum('jenis_perusahaan',['Swasta','Negeri']);
            $table->enum('class',['Tidak Sesuai','Sesuai'])->nullable();
            $table->enum('type',['training','testing'])->default('training');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('datasets');
    }
}
