<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\DatasetController;
use App\Http\Controllers\ExampleController;
use App\Http\Controllers\TestingController;
use App\Http\Controllers\ResultController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes();

Route::middleware(['auth'])->group(function () {
    Route::get('/',[HomeController::class,'index'])->name('dashboard');
    Route::get('/dataset',[DatasetController::class,'index'])->name('dataset.index');
    Route::post('/dataset',[DatasetController::class,'uploadFile'])->name('dataset.upload');
    Route::get('/dataset-tree',[DatasetController::class,'generateTree'])->name('dataset.tree');
    Route::get('/dataset-get-tree',[DatasetController::class,'getTree'])->name('dataset.getTree');
    Route::get('/datast-get-report',[DatasetController::class,'getReport'])->name('dataset.getReport');

    Route::get('/result',[ResultController::class,'index'])->name('result.index');
    
    Route::get('/testing',[TestingController::class,'index'])->name('testing.index');
    Route::post('/testing',[TestingController::class,'store'])->name('testing.store');
    Route::get('/testing-test',[TestingController::class,'test'])->name('testing.test');
    Route::delete('/testing',[TestingController::class,'destroy'])->name('testing.destroy'); 
});

//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
