@extends('layouts.template')

@section('content')
<div class="col-md-12 padding-0">
    <div  style="margin-bottom: 10px;">
        <a href="#" class="btn btn-primary" onclick="Tambah()"><i class="fa fa-plus"></i> Tambah Data</a>
        <a href="#" class="btn btn-danger" onclick="Truncate()"><i class="fa fa-trash"></i> Hapus Data</a>
        <a style="float: right" href="#" class="btn btn-success" id="testing">Proses Data</a>
        
    </div>
    <div class="table-responsive">
        <table id="table" class="table table-stripped table-bordered">
            <thead>
                <tr style="font-size: 10px;">
                    <th>Jenis Kelamin</th>
                    <th>Tahun Masuk</th>
                    <th>Tahun Lulus</th>
                    <th>Lama Studi</th>
                    <th>IPK</th>
                    <th>Lama Menganggur</th>
                    <th>Matkul Pendukung</th>
                    <th>Perusahaan Pertama Bekerja</th>
                    <th>Kesesuaian (class)</th>
                </tr>
            </thead>
            <tbody></tbody> 
        </table>
    </div>
</div>
@include('testing.form_tambah')
@endsection

@section('js')
    <script type="text/javascript">
        var tabel;
        $(document).ready(function (){
            $.ajaxSetup({
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })

            tabel = $('#table').DataTable({
                processing:true,
                serverSide:true,
                ajax:"{{route('testing.index')}}",
                columns: [
                    {data:'gender'},
                    {data:'tahun_masuk'},
                    {data:'tahun_lulus'},
                    {data:'lama_studi'},
                    {data:'ipk'},
                    {data:'durasi_menganggur'},
                    {data:'matkul_pendukung'},
                    {data:'jenis_perusahaan'},
                    {data:'class'}
                ]
            });

            $('#testing').on('click', function (e){
                $(this).text('Memproses...').attr('disabled',true);
                $.ajax({
                    url: "{{route('testing.test')}}",
                    method:"get",
                    cache:false,
                    contentType:false,
                    processData:false, 
                    beforeSend:function(){
                        Swal.showLoading()
                    },
                    success:function(res){
                        console.log(res)
                        tabel.ajax.reload()
                        $('#testing').text('Proses Data').attr('disabled',false);
                        msg('success','Proses Data Sukses')
                    },
                    error:function(jqXHR, textStatus, errorThrown){
                        $('#testing').text('Proses Data').attr('disabled',false);
                        msg('error','Proses Data Gagal')
                    }
                })
            })

            $('#form-tambah').on('submit', function (e){
                e.preventDefault();
                $('#simpan').text('Menambah...').attr('disabled', true);
                $.ajax({
                    url: "{{route('testing.store')}}",
                    method:"post",
                    data: $(this).serialize(),
                    beforeSend:function(){
                    $('#modal-tambah').modal('hide');
                        Swal.showLoading()
                    },
                    success:function(res){
                        tabel.ajax.reload();
                        $('#simpan').text('Tambah').attr('disabled',false);
                        msg('success','Tambah Data Sukses')
                    },
                    error:function(jqXHR, textStatus, errorThrown){
                        console.log(jqXHR, textStatus, errorThrown)
                        $('#simpan').html('Tambah').attr('disabled',false);
                        msg('error','Tambah Data Gagal')
                    }
                })

            })
        })

        function Tambah(){
            $('#form-tambah')[0].reset();
            $('.modal-title').text('Tambah Data');
            $('#modal-tambah').modal('show');
        }

        function Truncate(){
            Swal.fire({
            title: 'Ingin kosongkan data?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya'
            }).then((res)=>{
                if(res.value){
                    $.ajax({
                        url:"{{route('testing.destroy')}}",
                        type:"DELETE",
                        success:function(res){
                            tabel.ajax.reload();
                            msg('success','Data dihapus')
                        },
                        error:function(jqXHR, textStatus, errorThrown){
                            msg('error','Data Gagal dihapus')
                        }
                    });
                }
            });
        }

    </script>
@endsection 