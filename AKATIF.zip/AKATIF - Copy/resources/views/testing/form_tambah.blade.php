<div id="modal-tambah" class="modal fade">
    <div class="modal-dialog">
        <form id="form-tambah">
            <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="gender" class="control-label">Jenis Kelamin</label>
                                <select name="gender" class="form-control">
                                    <option value="Laki-laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="gender" class="control-label">Tahun Masuk</label>
                                <select id="tahun_masuk" name="tahun_masuk" class="form-control">
                                    <option value="1999-2004">1999-2004</option>
                                    <option value="2005-2010">2005-2010</option>
                                    <option value="2011-2016">2011-2016</option>
                                    <option value="2017-2022">2017-2022</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="gender" class="control-label">Tahun Lulus</label>
                                <select name="tahun_lulus" class="form-control">
                                    <option value="2004-2009">2004-2009</option>
                                    <option value="2010-2015">2010-2015</option>
                                    <option value="2016-2021">2016-2021</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="gender" class="control-label">Lama Studi</label>
                                <select name="lama_studi" class="form-control">
                                    <option value="4 th">4 th</option>
                                    <option value="5 th">5 th</option>
                                    <option value="6 th">6 th</option>
                                    <option value="7 th">7 th</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="gender" class="control-label">IPK</label>
                                <select name="ipk" class="form-control">
                                    <option value="Kurang">Kurang</option>
                                    <option value="Cukup">Cukup</option>
                                    <option value="Baik">Baik</option>
                                    <option value="Sangat Baik">Sangat Baik</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="gender" class="control-label">Durasi Menganggur</label>
                                <select name="durasi_menganggur" class="form-control">
                                    <option value="1 - 6 Bulan">1 - 6 Bulan</option>
                                    <option value="7 - 12 Bulan">7 - 12 Bulan</option>
                                    <option value="13 - 18 Bulan">13 - 18 Bulan</option>
                                    <option value="19 - 24 Bulan">19 - 24 Bulan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="gender" class="control-label">Matkul Pendukung</label>
                                <select name="matkul_pendukung" class="form-control">
                                    <option value="Ilkom">Ilkom</option>
                                    <option value="TI">TI</option>
                                    <option value="Combined">Combined</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="gender" class="control-label">Perusaahaan Pertama Bekerja</label>
                                <select name="jenis_perusahaan" class="form-control">
                                    <option value="Swasta">Swasta</option>
                                    <option value="Negeri">Negeri</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                <button type="submit" id="simpan" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah</button>
                </div>
            </div>
        </form>
    </div>
</div>