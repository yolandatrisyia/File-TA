<div id="modal-import" class="modal fade">
    <div class="modal-dialog">
        <form id="form-import">
            <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body">
                <input type="file" required accept=".xlsx" name="dataset">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                <button type="submit" id="import" class="btn btn-primary"><i class="fa fa-upload"></i> Upload</button>
                </div>
            </div>
        </form>
    </div>
</div>