@extends('layouts.template')

@section('breadcrumb')
    <h3 class="animated fadeInLeft">Classification Result</h3>
@endsection

@section('content')
    <div class="col-md-12 padding-0">
        <div  style="margin-bottom: 10px;">
             <a href="#" class="btn btn-warning" id="generate">Generete Tree</a>
        </div>
        <div  style="margin-top: 20px;">
            <h3>Decision Tree</h3>
             <div id="tree"></div>
        </div>
    </div>

    <div class="col-md-12 padding-0">
        <div  style="margin-top: 20px;">
            <h3>Akurasi: <span id="accuracy"></span></h3>
            <div class="col-md-6 col-xs-12">
                <h3>Confusion Matrix</h3>
                <table id="confusion_matrix" class="table table-bordered"></table>
            </div>
            <div class="col-md-6 col-xs-12">
                <h3>Classification Report</h3>
                <table id="classification_report" class="table table-bordered"></table>
            </div>
        </div>
    </div>
    @include('dataset.form_import')
@endsection

@section('js')
    <script type="text/javascript">
    var tabel;
        $(document).ready(function (){
            GetTree()
            GetReport()
            $.ajaxSetup({
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })

            $('#generate').on('click', function (e){
                $(this).text('Menggenerate...').attr('disabled',true);
                $.ajax({
                    url: "{{route('dataset.tree')}}",
                    method:"get",
                    cache:false,
                    contentType:false,
                    processData:false, 
                    beforeSend:function(){
                        Swal.showLoading()
                    },
                    success:function(res){
                        $('#generate').text('Generete Tree').attr('disabled',false);
                        msg('success','Generate Tree Sukses')
                        GetTree()
                        GetReport()
                    },
                    error:function(jqXHR, textStatus, errorThrown){
                        $('#generate').text('Generete Tree').attr('disabled',false);
                        msg('error','Generate Tree Gagal')
                        GetTree()
                        GetReport()
                    }
                })
            })
        });

        function GetTree(){
            $.get("{{route('dataset.getTree')}}",function (response){
                document.getElementById("tree").innerHTML = '<pre>'+response.result+'</pre>';
            })
        }

        function GetReport(){
            $.get("{{route('dataset.getReport')}}",function (response){
                document.getElementById("accuracy").innerHTML = response.acuracy ?? 0;
                let cofusion_matrix = JSON.parse(response.confusion_matrix);
                let label = ['Sesuai','Tidak Sesuai'];
                let data_cm = '<tr><th rowspan="2" colspan="2" style="background-color:rgb(0, 132, 255)"></th><th colspan="2" class="text-center">Aktual</th></tr>';
                data_cm += '<tr><th class="text-center">Sesuai</th><th class="text-center">Tidak Sesuai</th></tr><tr><th class="text-center" rowspan="3">Prediksi</th></tr>';
                $.each(cofusion_matrix, function (index, value){
                    data_cm += '<tr><th class="text-center">'+label[index]+'</th>';
                    $.each(value, function (i, v){
                        data_cm += '<th class="text-center">'+v+'</th>';
                    })
                    data_cm += '</tr>';
                })
                document.getElementById("confusion_matrix").innerHTML = data_cm;
                let classification_report = JSON.parse(response.classification_report)
                let data_cr = '<tr><th class="text-center">JENIS</th><th class="text-center">Sesuai</th><th class="text-center">Tidak Sesuai</th></tr>';
                $.each(classification_report, function(index,value){
                    data_cr += '<tr><th class="text-center">'+index.toUpperCase()+'</th>';
                    $.each(value, function (i, v) {
                        if (index != 'support')
                            data_cr += '<th class="text-center">'+v.toFixed(2)+'</th>'
                        else
                            data_cr += '<th class="text-center">'+v+'</th>'
                    })
                    data_cr += '</tr>';
                })
                document.getElementById("classification_report").innerHTML = data_cr;              
            })
        }

    </script>
@endsection