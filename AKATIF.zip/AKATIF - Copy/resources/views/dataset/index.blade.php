@extends('layouts.template')

@section('breadcrumb')
    <h3 class="animated fadeInLeft">Data Training</h3>
@endsection

@section('content')
    <div class="col-md-12 padding-0">
        <div  style="margin-bottom: 10px;">
            <a href="#" class="btn btn-primary" onclick="Import()"><i class="fa fa-upload"></i> Upload Data</a>
        </div>
        <div class="table-responsive">
            <table id="table" class="table table-stripped table-bordered">
                <thead>
                    <tr style="font-size: 10px;">
                        <th>Jenis Kelamin</th>
                        <th>Tahun Masuk</th>
                        <th>Tahun Lulus</th>
                        <th>Lama Studi</th>
                        <th>IPK</th>
                        <th>Lama Menganggur</th>
                        <th>Matkul Pendukung</th>
                        <th>Perusahaan Pertama Bekerja</th>
                        <th>Kesesuaian (class)</th>
                    </tr>
                </thead>
                <tbody></tbody> 
            </table>
        </div>
    </div>
    @include('dataset.form_import')
@endsection

@section('js')
    <script type="text/javascript">
    var tabel;
        $(document).ready(function (){
            $.ajaxSetup({
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })

            tabel = $('#table').DataTable({
                processing:true,
                serverSide:true,
                ajax:"{{route('dataset.index')}}",
                columns: [
                    {data:'gender'},
                    {data:'tahun_masuk'},
                    {data:'tahun_lulus'},
                    {data:'lama_studi'},
                    {data:'ipk'},
                    {data:'durasi_menganggur'},
                    {data:'matkul_pendukung'},
                    {data:'jenis_perusahaan'},
                    {data:'class'}
                ]
            });

            $('#form-import').on('submit',function(e){
                e.preventDefault();
                $('#import').text('Mengupload...').attr('disabled',true);
                $.ajax({
                    url: "{{route('dataset.upload')}}",
                    method:"post",
                    data: new FormData(this),
                    cache:false,
                    contentType:false,
                    processData:false,
                    beforeSend:function(){
                    $('#modal-import').modal('hide');
                        Swal.showLoading()
                    },
                    success:function(res){
                        tabel.ajax.reload();
                        $('#import').text('Import').attr('disabled',false);
                        msg('success','Upload Data Sukses')
                    },
                    error:function(jqXHR, textStatus, errorThrown){
                        tabel.ajax.reload();
                        $('#import').html('Import').attr('disabled',false);
                        msg('error','Upload Data Gagal')
                    }
                })
            });
        });

        function Import(){
            $('#form-import')[0].reset();
            $('.modal-title').text('Import Data');
            $('#modal-import').modal('show');
        }

    </script>
@endsection