<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dataset;
use Algorithm\C45;
use DataTables;
use Batch;


class TestingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(Request $request){
        if($request->ajax()){
            $testing = Dataset::where('type','testing');
            return DataTables::of($testing)->make(true);
        }
        return view('testing.index');
    }

    public function store(Request $request){
        $dataset = Dataset::create([
            'gender' => $request->gender,
            'tahun_masuk' => $request->tahun_masuk,
            'tahun_lulus'   => $request->tahun_lulus,
            'lama_studi'    => $request->lama_studi,
            'ipk'   => $request->ipk,
            'durasi_menganggur'  => $request->durasi_menganggur,
            'matkul_pendukung' => $request->matkul_pendukung,
            'jenis_perusahaan' => $request->jenis_perusahaan,
            'type'  => 'testing'
        ]);
        if($dataset)
            return response()->json($dataset);
    }

    public function destroy(){
        $datasets = Dataset::where('type','testing')->delete();
        if($datasets)
            return response()->json($datasets);
    }

    public function test(){
        $c45 = new C45();
        $c45->loadFile('storage/dataset.xlsx')->setTargetAttribute('KESESUAIAN')->initialize();
        $buildTree = $c45->buildTree();
        $dataTest = Dataset::where('type','testing')->get();
        $datasetInstance = new Dataset;
        $index = 'id';
        $value = array();
        foreach($dataTest as $data){
            $new_data = array(
                'GENDER' => $data->gender,
                'MASUK' => $data->tahun_masuk,
                'LULUS' => $data->tahun_lulus,
                'STUDI' => $data->lama_studi,
                'IPK'   => $data->ipk,
                'MENGANGGUR'  => $data->durasi_menganggur,
                'MATKUL'    => $data->matkul_pendukung,
                'PERUSAHAAN' => $data->jenis_perusahaan
            );
            array_push($value,[
                'id' => $data->id,
                'class' =>$buildTree->classify($new_data)
            ]);
        }
        $batch = Batch::update($datasetInstance, $value, $index);
        return response()->json(['status' => $batch]);
    }
}
