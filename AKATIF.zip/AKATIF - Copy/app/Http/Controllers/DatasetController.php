<?php

namespace App\Http\Controllers;

use App\Imports\DatasetImport;
use Illuminate\Http\Request;
use Phpml\Metric\ConfusionMatrix;
use Phpml\Metric\ClassificationReport;
use Phpml\Metric\Accuracy;
use App\Models\Dataset;
use App\Models\Report;
use App\Models\Tree;
use Algorithm\C45;
use DataTables;
use Storage;
use Excel;

class DatasetController extends Controller
{
    private $actualLabel = [];
    private $predictLabel = [];

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request){
        if($request->ajax()){
            $dataset = Dataset::where('type','training');
            return DataTables::of($dataset)->make(true);
        }
        return view('dataset.index');
    }

    public function uploadFile(Request $request){
        $this->delete_file();
        $this->truncate();
        $file_upload = Storage::putFileAs('public', $request->file('dataset'),'dataset.xlsx');
        $excel = Excel:: import(new DatasetImport, $request->file('dataset'));
        return response()->json($excel);
    }

    private function delete_file(){
        if(Storage::exists('public/dataset.xlsx'));
            Storage::disk('public')->delete('dataset.xlsx');
        return;
    }

    private function truncate(){
        Dataset::truncate();
        Tree::truncate();
        return;
    }

    public function generateTree(){
        Tree::truncate();
        $c45 = new C45();
        $c45->loadFile('storage/dataset.xlsx')->setTargetAttribute('KESESUAIAN')->initialize();
        $buildTree = $c45->buildTree();
        $tree = Tree::create([
            'result' => $buildTree->toString()
        ]);
        if($tree){
            $dataset = Dataset::all();
            foreach($dataset as $data){
                $new_data = array(
                    'GENDER' => $data->gender,
                    'MASUK' => $data->tahun_masuk,
                    'LULUS' => $data->tahun_lulus,
                    'STUDI' => $data->lama_studi,
                    'IPK'   => $data->ipk,
                    'MENGANGGUR'  => $data->durasi_menganggur,
                    'MATKUL'    => $data->matkul_pendukung,
                    'PERUSAHAAN' => $data->jenis_perusahaan
                ); 
                array_push($this->actualLabel, $data->class);
                array_push($this->predictLabel,$buildTree->classify($new_data));
            }
            $this->updateReport();
            return $tree;
        }
    }

    public function getTree(){
        $tree = Tree::find(1);
        return response()->json($tree);
    }

    private function accuracy(){
        return 100*Accuracy::score($this->actualLabel, $this->predictLabel);
    }

    private function confusionMatrix(){
        return ConfusionMatrix::compute($this->actualLabel,$this->predictLabel);
    }

    private function classificationReport(){
        $report = new ClassificationReport($this->actualLabel, $this->predictLabel);
        $precission = $report->getPrecision();
        $recall = $report->getRecall();
        $f1Score = $report->getF1score();
        $support = $report->getSupport();
        return [
            'precission' => $precission,
            'recall'     => $recall,
            'f1Score'    => $f1Score,
            'support'    => $support
        ];
    }

    private function updateReport(){
        $report = Report::updateOrCreate(['id' => 1],[
            'acuracy'               => round($this->accuracy(),2). '%',
            'confusion_matrix'      => json_encode($this->confusionMatrix()),
            'classification_report' => json_encode($this->classificationReport())
        ]);
        return $report;
    }

    public function getReport(){
        $report = Report::find(1);
        if($report)
            return response()->json($report);
    }
}
