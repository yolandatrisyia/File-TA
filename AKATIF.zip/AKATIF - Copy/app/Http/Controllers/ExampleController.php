<?php

namespace App\Http\Controllers;

use Algorithm\C45;
use Illuminate\Http\Request;

class ExampleController extends Controller
{
    public function index()
    {
        $c45 = new C45();
        $c45->loadFile('storage/dataset.xlsx')->setTargetAttribute('KESESUAIAN')->initialize();
        $new_data = array(
            'GENDER' => 'Perempuan',
            'MASUK' => 2003,
            'LULUS' => 2008,
            'STUDI' => 2,
            'IPK'   => 3,
            'TUNGGU'    => 1,
            'MATKUL'    => 3,
            'PERUSAHAAN' => 'Negeri',
        );
        $buildTree = $c45->initialize()->buildTree();
        echo $buildTree->classify($new_data);
    }
}
