<?php

namespace App\Imports;

use App\Models\Dataset;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class DatasetImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
    {
        return new Dataset([
            'gender'  => $row['gender'],
            'tahun_masuk' => $row['masuk'],
            'tahun_lulus' => $row['lulus'],
            'lama_studi' => $row['studi'],
            'ipk' => $row['ipk'],
            'durasi_menganggur' => $row['menganggur'],
            'matkul_pendukung' => $row['matkul'],
            'jenis_perusahaan' => $row['perusahaan'],
            'class' => $row['kesesuaian'],
            'type'  => 'training'
        ]);
    }
}
