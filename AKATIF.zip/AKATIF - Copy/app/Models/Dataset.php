<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Dataset extends Model
{

    protected $fillable = [
        'name',
        'gender',
        'tahun_masuk',
        'tahun_lulus',
        'lama_studi',
        'ipk',
        'durasi_menganggur',
        'matkul_pendukung',
        'jenis_perusahaan',
        'class',
        'type',
    ];
}
